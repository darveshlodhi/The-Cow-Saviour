<?php $name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];
$formcontent="From: $name \n Message: $message";
$recipient = "darveshlodhi786@gmail.com";
$subject = "Contribute The Cow Saviour Form";
$mailheader = "From: $email \r\n";
mail($recipient, $subject, $formcontent, $mailheader) or die("Error!");
echo "Thank You!";
echo '<br></br>';
echo '<br></br>';
echo '<a href="index.html">Home </a>';
?>